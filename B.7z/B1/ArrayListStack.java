import java.util.ArrayList;

public class ArrayListStack {
    private ArrayList<Integer> intStack;

    public ArrayListStack(){
        intStack = new ArrayList<Integer>();
    }

    public void push(int elem){
        intStack.add(elem);
    }

    public int peek(){
        return intStack.get(intStack.size()-1);
    }

    public int pop(){
        int topElem = intStack.get(intStack.size()-1);
        intStack.remove(intStack.size()-1);
        return topElem;
    }

    public boolean isEmpty(){
        return intStack.isEmpty();
    }

    public static void main(String[] args){
        ArrayListStack theStack = new ArrayListStack();

        theStack.push(10);
        theStack.push(20);
        theStack.push(30);

        System.out.println("Szczyt stosu: "+theStack.peek());

        System.out.println("Usuwamy: "+theStack.pop());
        System.out.println("Usuwamy: "+theStack.pop());

        theStack.push(40);
        theStack.push(50);

        System.out.println("Stos: ");
        while(!theStack.isEmpty()){
            System.out.println(theStack.pop());
        }

    }
}
