import java.util.ArrayList;

public class ArrayListList{
    private ArrayList<Object> oList;

    public ArrayListList(){
        oList = new ArrayList<Object>();
    }

    public boolean addLast(Object elem){
        return oList.add(elem);
    }

    public Object removeLast(){
        int lastIndex = oList.size()-1;
        return oList.remove(lastIndex);
    }

    public Object get(int index){
        return oList.get(index);
    }

    public int find(Object elem){
        return oList.indexOf(elem);
    }

    public int size(){
        return oList.size();
    }

    public void print(){
        for (int i=0; i<oList.size(); i++) {
            System.out.print(oList.get(i)+" ");
        }
        System.out.println("");
    }

    public static void main(String[] args){
        ArrayListList theList = new ArrayListList();

        theList.addLast(10);
        theList.addLast(20);
        theList.addLast(30);
        theList.addLast(40);

        theList.print();

        Object D = theList.removeLast();

        theList.removeLast();
        theList.removeLast();

        theList.addLast(D);

        theList.print();

        theList.addLast(50);
        theList.addLast(60);

        theList.print();
    }
}