import java.util.LinkedList;

public class LinkedListQueue {
    private LinkedList<Integer> intQueue;

    public LinkedListQueue(){
        intQueue = new LinkedList<Integer>();
    }

    public void insert(int elem){
        intQueue.addLast(elem);
    }

    public int remove(){
        int FirstElem = intQueue.get(0).intValue();
        intQueue.removeFirst();
        return FirstElem;
    }

    public int peek(){
        return intQueue.peekFirst().intValue();
    }

    public boolean isEmpty(){
        return intQueue.isEmpty();
    }

    public int size(){
        return intQueue.size();
    }

    public static void main(String[] args){
        LinkedListQueue theQueue = new LinkedListQueue();

        theQueue.insert(10);
        theQueue.insert(20);
        theQueue.insert(30);

        System.out.println("Pierwszy w kolejce: "+theQueue.peek());

        System.out.println("Usuwamy: "+theQueue.remove());
        System.out.println("Usuwamy: "+theQueue.remove());

        theQueue.insert(40);
        theQueue.insert(50);

        System.out.println("Kolejka: ");
        while (!theQueue.isEmpty()){
            System.out.println(theQueue.remove());
        }
    }
}
