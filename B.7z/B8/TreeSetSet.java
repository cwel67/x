import java.util.TreeSet;
import java.util.Iterator;

public class TreeSetSet {
    private TreeSet<Integer> treeSet;

    public TreeSetSet(){
        treeSet = new TreeSet<Integer>();
    }

    public int size(){
        return treeSet.size();
    }

    public void insert(int elem){
        if(!member(elem)){
            treeSet.add(elem);
        }
    }

    public TreeSet<Integer> getTreeSet(){
        return treeSet;
    }

    public boolean member(int elem){
        return treeSet.contains(elem);
    }

    public boolean delete(int elem){
        if(member(elem)){
            treeSet.remove(elem);
            return true;
        } else return false;
    }

    public TreeSetSet union(TreeSetSet secondSet){
        TreeSetSet unionSet = new TreeSetSet();
        Iterator<Integer> iterator = treeSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            unionSet.insert(locElem);
        }

        Iterator<Integer> iteratorS = secondSet.treeSet.iterator();
        while (iteratorS.hasNext()){
            int locElem = iteratorS.next().intValue();
            unionSet.insert(locElem);
        }
        return unionSet;
    }

    public TreeSetSet intersection(TreeSetSet secondSet){
        TreeSetSet intersectionSet = new TreeSetSet();
        Iterator<Integer> iterator = treeSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(secondSet.member(locElem)){
                intersectionSet.insert(locElem);
            }
        }
        return intersectionSet;
    }

    public TreeSetSet difference(TreeSetSet secondSet){
        TreeSetSet differenceSet = new TreeSetSet();
        Iterator<Integer> iterator = treeSet.iterator();
        while(iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(!secondSet.member(locElem)){
                differenceSet.insert(locElem);
            }
        }
        return differenceSet;
    }

    public void print(){
        Iterator<Integer> iterator = treeSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            System.out.print(locElem+" ");
        }
        System.out.println("");
    }

    public static void main(String[] args){
        TreeSetSet theSetA = new TreeSetSet();
        TreeSetSet theSetB = new TreeSetSet();

        theSetA.insert(10);
        theSetA.insert(20);
        theSetA.insert(30);
        theSetA.insert(40);

        theSetB.insert(30);
        theSetB.insert(40);
        theSetB.insert(50);

        System.out.println("Zbiór A: ");
        theSetA.print();

        System.out.println("Zbiór B: ");
        theSetB.print();

        System.out.println("Suma: ");
        TreeSetSet unionSet = theSetA.union(theSetB);
        unionSet.print();

        System.out.println("Iloczyn: ");
        TreeSetSet intersectionSet = theSetA.intersection(theSetB);
        intersectionSet.print();

        System.out.println("Różnica: ");
        TreeSetSet differenceSet = theSetA.difference(theSetB);
        differenceSet.print();
    }
}
