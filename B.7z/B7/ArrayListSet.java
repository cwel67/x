import java.util.*;
import java.io.*;

public class ArrayListSet {
    private ArrayList<Integer> integerSet;

    public ArrayListSet(){
        integerSet = new ArrayList<Integer>();
    }

    public int size(){
        return integerSet.size();
    }

    public void insert(int elem){
        if(!member(elem)) {
            integerSet.add(elem);
        }
    }

    public int get(int index){
        return integerSet.get(index).intValue();
    }

    public boolean member(int elem){
        return integerSet.contains(elem);
    }

    public boolean delete(int elem){
        int position=-1;
        for (int i=0; i<size(); i++){
            if(get(i)==elem) {
                position = i;
                break;
            }
        }
        if(position>-1){
            integerSet.remove(position);
            return true;
        }
        return false;
    }

    public ArrayListSet union(ArrayListSet secondSet){
        ArrayListSet unionSet = new ArrayListSet();
        for (int i=0;i<size();i++){
            int locElem = get(i);
            unionSet.insert(locElem);
        }
        for (int i=0;i< secondSet.size();i++){
            int locElem = secondSet.get(i);
            unionSet.insert(locElem);
        }
        return unionSet;
    }

    public ArrayListSet intersection(ArrayListSet secondSet){
        ArrayListSet intersectionSet = new ArrayListSet();
        for (int i=0; i<size(); i++){
            int locElem = get(i);
            if(secondSet.member(locElem))
                intersectionSet.insert(locElem);
        }
        return intersectionSet;
    }

    public ArrayListSet difference(ArrayListSet secondSet){
        ArrayListSet differenceSet = new ArrayListSet();
        for (int i=0;i<size();i++){
            int locElem = get(i);
            if(!secondSet.member(locElem))
                differenceSet.insert(locElem);
        }
        return differenceSet;
    }

    public void print(){
        for (int i=0;i<size();i++){
            int locElem = get(i);
            System.out.print(locElem+" ");
        }
        System.out.println("");
    }

    public static void main(String[] args){
        ArrayListSet theSetA = new ArrayListSet();
        ArrayListSet theSetB = new ArrayListSet();

        theSetA.insert(10);
        theSetA.insert(20);
        theSetA.insert(30);
        theSetA.insert(40);

        theSetB.insert(30);
        theSetB.insert(40);
        theSetB.insert(50);

        System.out.println("Zbiór A: ");
        theSetA.print();

        System.out.println("Zbiór B: ");
        theSetB.print();

        System.out.println("Iloczyn: ");
        ArrayListSet intersectionSet = theSetA.intersection(theSetB);
        intersectionSet.print();

        System.out.println("Suma: ");
        ArrayListSet unionSet = theSetA.union(theSetB);
        unionSet.print();

        System.out.println("Różnica: ");
        ArrayListSet differenceSet = theSetA.difference(theSetB);
        differenceSet.print();

        theSetA.delete(30);
        theSetB.delete(50);

        System.out.println("Zbiór A: ");
        theSetA.print();

        System.out.println("Zbiór B: ");
        theSetB.print();

        System.out.println("Iloczyn: ");
        ArrayListSet intersectionSet2 = theSetA.intersection(theSetB);
        intersectionSet2.print();

        System.out.println("Suma: ");
        ArrayListSet unionSet2 = theSetA.union(theSetB);
        unionSet2.print();

        System.out.println("Różnica: ");
        ArrayListSet differenceSet2 = theSetA.difference(theSetB);
        differenceSet2.print();
    }
}