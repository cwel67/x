import java.util.HashSet;
import java.util.Iterator;

public class HashSetSet {
    private HashSet<Integer> hashSet;

    public HashSetSet(){
        hashSet = new HashSet<Integer>();
    }
    public int size(){
        return hashSet.size();
    }
    public void insert(int elem){
        if (!member(elem)){
            hashSet.add(elem);
        }
    }
    public HashSet<Integer> getHashSet(){
        return hashSet;
    }
    public boolean member(int elem){
        return hashSet.contains(elem);
    }
    public boolean delete(int elem){
        if(member(elem)){
            hashSet.remove(elem);
            return true;
        }
        else {
            return false;
        }
    }
    public HashSetSet union(HashSetSet secondSet){
        HashSetSet unionSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            unionSet.insert(locElem);
        }

        Iterator<Integer> iteratorS = secondSet.getHashSet().iterator();
        while (iteratorS.hasNext()){
            int locElem = iteratorS.next().intValue();
            unionSet.insert(locElem);
        }
        return unionSet;
    }
    public HashSetSet intersection(HashSetSet secondSet){
        HashSetSet intersectionSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while(iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(secondSet.member(locElem)){
                intersectionSet.insert(locElem);
            }
        }
        return intersectionSet;
    }
    public HashSetSet difference(HashSetSet secondSet){
        HashSetSet differenceSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(secondSet.member(locElem)){
                differenceSet.insert(locElem);
            }
        }
        return differenceSet;
    }
    public void print(){
        Iterator<Integer> iterator = hashSet.iterator();
        while(iterator.hasNext()){
            int locElem = iterator.next().intValue();
            System.out.printf(locElem+" ");
        }
        System.out.println("");
    }
    public static void main(String[] args){
        HashSetSet theSetA = new HashSetSet();
        HashSetSet theSetB = new HashSetSet();

        theSetA.insert(1);
        theSetA.insert(2);
        theSetA.insert(3);
        theSetA.insert(4);

        theSetB.insert(3);
        theSetB.insert(4);
        theSetB.insert(5);

        theSetA.print();
        theSetB.print();

        HashSetSet unionSet = theSetA.union(theSetB);
        HashSetSet intersectionSet = theSetA.intersection(theSetB);
        HashSetSet differenceSet = theSetA.difference(theSetB);

        unionSet.print();
        intersectionSet.print();
        differenceSet.print();
    }
}