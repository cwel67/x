import java.util.HashSet;
import java.util.Iterator;

public class HashSetSet {
    private HashSet<Integer> hashSet;

    public HashSetSet(){
        hashSet = new HashSet<Integer>();
    }
    public int size(){
        return hashSet.size();
    }
    public void insert(int elem){
        if (!member(elem)){
            hashSet.add(elem);
        }
    }
    public HashSet<Integer> getHashSet(){
        return hashSet;
    }
    public boolean member(int elem){
        return hashSet.contains(elem);
    }
    public boolean delete(int elem){
        if(member(elem)){
            hashSet.remove(elem);
            return true;
        }
        else {
            return false;
        }
    }
    public HashSetSet union(HashSetSet secondSet){
        HashSetSet unionSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            unionSet.insert(locElem);
        }

        Iterator<Integer> iteratorS = secondSet.getHashSet().iterator();
        while (iteratorS.hasNext()){
            int locElem = iteratorS.next().intValue();
            unionSet.insert(locElem);
        }
        return unionSet;
    }
    public HashSetSet intersection(HashSetSet secondSet){
        HashSetSet intersectionSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while(iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(secondSet.member(locElem)){
                intersectionSet.insert(locElem);
            }
        }
        return intersectionSet;
    }
    public HashSetSet difference(HashSetSet secondSet){
        HashSetSet differenceSet = new HashSetSet();
        Iterator<Integer> iterator = hashSet.iterator();
        while (iterator.hasNext()){
            int locElem = iterator.next().intValue();
            if(!secondSet.member(locElem)){
                differenceSet.insert(locElem);
            }
        }
        return differenceSet;
    }
    public void print(){
        Iterator<Integer> iterator = hashSet.iterator();
        while(iterator.hasNext()){
            int locElem = iterator.next().intValue();
            System.out.printf(locElem+" ");
        }
        System.out.println("");
    }
    public static void main(String[] args){
        HashSetSet theSetA = new HashSetSet();
        HashSetSet theSetB = new HashSetSet();

        theSetA.insert(10);
        theSetA.insert(20);
        theSetA.insert(30);
        theSetA.insert(40);

        theSetB.insert(30);
        theSetB.insert(40);
        theSetB.insert(50);

        System.out.println("Zbiór A: ");
        theSetA.print();

        System.out.println("Zbiór B: ");
        theSetB.print();

        System.out.println("Iloczyn: ");
        HashSetSet intersectionSet = theSetA.intersection(theSetB);
        intersectionSet.print();

        System.out.println("Suma: ");
        HashSetSet unionSet = theSetA.union(theSetB);
        unionSet.print();

        System.out.println("Różnica: ");
        HashSetSet differenceSet = theSetA.difference(theSetB);
        differenceSet.print();

        theSetA.delete(30);
        theSetB.delete(50);

        System.out.println("Zbiór A: ");
        theSetA.print();

        System.out.println("Zbiór B: ");
        theSetB.print();

        System.out.println("Iloczyn: ");
        HashSetSet intersectionSet2 = theSetA.intersection(theSetB);
        intersectionSet2.print();

        System.out.println("Suma: ");
        HashSetSet unionSet2 = theSetA.union(theSetB);
        unionSet2.print();

        System.out.println("Różnica: ");
        HashSetSet differenceSet2 = theSetA.difference(theSetB);
        differenceSet2.print();
    }
}