import java.util.ArrayList;

public class ArrayListQueue {
    private ArrayList<Integer> intQueue;

    public ArrayListQueue(){
        intQueue = new ArrayList<Integer>();
    }

    public void insert(int elem){
        intQueue.add(elem);
    }

    public int remove(){
        int FirstElem = intQueue.get(0).intValue();
        intQueue.remove(0);
        return FirstElem;
    }

    public int peek(){
        return intQueue.get(0).intValue();
    }

    public boolean isEmpty(){
        return intQueue.isEmpty();
    }

    public int size(){
        return intQueue.size();
    }

    public static void main(String[] args){
        ArrayListQueue theQueue = new ArrayListQueue();

        theQueue.insert(10);
        theQueue.insert(20);
        theQueue.insert(30);

        theQueue.remove();
        theQueue.remove();

        theQueue.insert(40);
        theQueue.insert(50);

        System.out.println("Kolejka: ");
        while (!theQueue.isEmpty()){
            System.out.println(theQueue.remove());
        }
    }
}