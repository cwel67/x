import java.util.LinkedList;

public class LinkedListList {
    private LinkedList<Object> oList;

    public LinkedListList(){
        oList = new LinkedList<Object>();
    }

    public boolean isEmpty(){
        return oList.isEmpty();
    }

    public void addLast(Object elem){
        oList.addLast(elem);
    }
    public void addFirst(Object elem){
        oList.addFirst(elem);
    }
    public Object removeLast(){
        return oList.removeLast();
    }
    public Object removeFirst(){
        return oList.removeFirst();
    }

    public Object getLast(){
        return oList.getLast();
    }
    public Object getFirst(){
        return oList.getFirst();
    }
    public int size(){
        return oList.size();
    }
    public void print(){
        for (int i=0; i<oList.size(); i++){
            System.out.printf(oList.get(i)+" ");
        }
        System.out.println("");
    }
    public static void main(String[] args){
        LinkedListList theListL = new LinkedListList();

        theListL.addFirst(10);
        theListL.addFirst(20);
        theListL.addFirst(30);

        theListL.print();

        theListL.addLast(40);
        theListL.addLast(50);

        theListL.print();

        theListL.removeFirst();
        theListL.removeLast();

        theListL.print();

        System.out.println("20: " + theListL.oList.contains(20));
        System.out.println("50: " + theListL.oList.contains(50));
    }
}