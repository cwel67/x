import java.util.LinkedList;

public class LinkedListList {
    private LinkedList<Object> oList;

    public LinkedListList(){
        oList = new LinkedList<Object>();
    }

    public boolean isEmpty(){
        return oList.isEmpty();
    }

    public void addLast(Object elem){
        oList.addLast(elem);
    }
    public void addFirst(Object elem){
        oList.addFirst(elem);
    }
    public Object removeLast(){
        return oList.removeLast();
    }
    public Object removeFirst(){
        return oList.removeFirst();
    }

    public Object getLast(){
        return oList.getLast();
    }
    public Object getFirst(){
        return oList.getFirst();
    }
    public int size(){
        return oList.size();
    }
    public void print(){
        for (int i=0; i<oList.size(); i++){
            System.out.printf(oList.get(i)+" ");
        }
        System.out.println("");
    }
    public static void main(String[] args){
        LinkedListList theList = new LinkedListList();

        theList.addFirst("A");
        theList.addFirst("B");
        theList.addFirst("C");

        theList.print();

        theList.addLast("D");
        theList.addLast("E");

        theList.print();

        theList.removeFirst();
        theList.removeLast();

        theList.print();

        System.out.println("B: " + theList.oList.contains("B"));
        System.out.println("E: " + theList.oList.contains("E"));
    }
}