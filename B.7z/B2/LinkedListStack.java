import java.util.LinkedList;

public class LinkedListStack {
    private LinkedList<Integer> intStack;

    public LinkedListStack(){
        intStack = new LinkedList<Integer>();
    }

    public void push(int elem){
        intStack.push(elem);
    }

    public int peek(){
        return intStack.peek();
    }

    public int pop(){
        return intStack.pop();
    }

    public boolean isEmpty(){
        return intStack.isEmpty();
    }

    public static void main(String[] args){
        LinkedListStack theStack = new LinkedListStack();

        theStack.push(10);
        theStack.push(20);
        theStack.push(30);

        theStack.pop();
        theStack.pop();

        theStack.push(40);
        theStack.push(50);

        System.out.println("Stos: ");
        while (!theStack.isEmpty()){
            System.out.println(theStack.pop());
        }

    }
}